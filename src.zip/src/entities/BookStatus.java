package entities;

public enum BookStatus {
    AVAILABLE,
    UNAVAILABLE;
}
